# 📝 User Guide

## Author
- cre: NguyenBaTai

## 1️⃣ Preparation
- Two required files:  
  - `excute.sh`  
  - `setting.txt` (3 lines as above)

- **Paste into the `/tmp` directory** on your Android device.

## 2️⃣ Running the Program
- Open **MT** and run `excute.sh`.  
- Observe the output in the MT console.  
- Can be checked using **Game Guardian**.

## 3️⃣ Functions
- **Mode 1 (FUNCTION)**  
  ⬩ Wait for the game to fully load → enable each feature → the program will only print newly appeared function addresses.  
- **Mode 2 (AUTO)**  
  ⬩ Continuous monitoring → prints all new memory changes.

## ⚠️ Notes
- Only two files needed; the program will automatically stop when the game exits.

---Use Google Translate to convert to your language.